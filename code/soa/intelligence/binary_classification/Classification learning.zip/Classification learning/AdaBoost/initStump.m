function stump = initStump(dim)
stump.dim = dim;
stump.error = 1e6;
stump.threshold = [];
stump.less = 1;
stump.more = -1;
end
